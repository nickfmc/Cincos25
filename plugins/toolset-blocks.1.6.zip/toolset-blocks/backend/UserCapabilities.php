<?php

namespace OTGS\Toolset\Views\UserCapabilities {
	const EDIT_VIEWS = 'toolset_edit_views';
}

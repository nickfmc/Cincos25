# REST API backend for new views editor

Uses PSR-4 autoloading mechanism and API namespacing.

API root is `toolset-views/v1`, all controllers are located under `Controllers\V1` folder.

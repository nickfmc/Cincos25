<?php

use OTGS\Toolset\Types\Filesystem\File;

if ( false ) {
	/** @deprecated */
	class Toolset_Filesystem_File extends \OTGS\Toolset\Types\Filesystem\File { }
}

class_exists( File::class );

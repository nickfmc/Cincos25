<?php

use \OTGS\Toolset\Types\Ajax\Handler\ReevaluateDisplayedFieldGroups;

if ( false ) {
	/** @deprecated  */
	class Types_Ajax_Handler_Reevaluate_Displayed_Field_Groups extends ReevaluateDisplayedFieldGroups { }
}
class_exists( ReevaluateDisplayedFieldGroups::class );

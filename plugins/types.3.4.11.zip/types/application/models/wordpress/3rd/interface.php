<?php

/**
 * Interface Types_Wordpress_3rd_Interface
 *
 * @since 2.3
 */
interface Types_Wordpress_3rd_Interface {
	/**
	 * @return bool
	 */
	public function is_active();
}